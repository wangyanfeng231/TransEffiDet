# -*- coding = utf-8 -*-
# @time:2021/4/29 下午8:51
# Author:jy
# @File:test_detransformer.py
# @Software:PyCharm


import torch
from torch import nn
from position_encoding import PositionEmbeddingSine
from deformable_transformer import DeformableTransformer


class Transform(nn.Module):
    def __init__(self, num_feature_levels=1, hidden_dim= 128,num_feats=16):
        super(Transform, self).__init__()
        self.position_embed = PositionEmbeddingSine(num_pos_feats=num_feats)
        self.encoder_Detrans = DeformableTransformer(d_model=hidden_dim, dim_feedforward=hidden_dim*4, dropout=0.1, activation='gelu',\
                                                     num_feature_levels=num_feature_levels, nhead=8, num_encoder_layers=6, enc_n_points=4)
    def posi_mask(self, x):

        x_fea = []
        x_posemb = []
        masks = []
        for lvl, fea in enumerate(x):   # 对于每一层
            if lvl >= 0:
                x_fea.append(fea)
                x_posemb.append(self.position_embed(fea))
                masks.append(torch.zeros((image.shape[0], image.shape[2], image.shape[3]), dtype=torch.bool).cuda())    # bs d h w

        return x_fea, masks, x_posemb

    def forward(self, inputs):
        shape0 = inputs[0].shape
        x_fea, masks, x_posemb = self.posi_mask(inputs)
        x_trans = self.encoder_Detrans(x_fea, masks, x_posemb)
        # Multi-scale
        # x = x_trans[:, 6912::].transpose(-1, -2).view(inputs[-1].shape) # x_trans length: 12*24*24+6*12*12=7776
        x = x_trans[:, 0:shape0[2]*shape0[3]].transpose(-1, -2).view(inputs[0].shape)

        return x

if __name__ == '__main__':
    device = torch.device('cuda:0')
    image = torch.randn(1, 32, 128,128)
    image = image.to(device)
    TR = Transform(hidden_dim= 32, num_feats = 16).cuda()
    output = TR([image])
    a = 1